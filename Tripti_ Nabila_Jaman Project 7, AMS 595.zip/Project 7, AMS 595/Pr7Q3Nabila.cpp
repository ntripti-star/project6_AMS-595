// Question 3: Using While Loop Return elements of the Fibonacci sequence

#include <iostream>

int main() {
    long long c = 1, d = 2; // Starting with the first two Fibonacci numbers
    std::cout << c << ", " << d; // It will print the first two numbers

    long long nxt = c + d; // Calculate the next Fibonacci number
    while (nxt <= 4000000) { // Loop while the number is <= 4,000,000
        std::cout << ", " << nxt; // Print the current Fibonacci number
        c = d;              // Shift the numbers
        d = nxt;           // Move to the next Fibonacci number
        nxt = c + d;       // Calculate the new Fibonacci number
    }

    std::cout << std::endl;
    return 0;
}
