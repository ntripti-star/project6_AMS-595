// Question 2: Printing a Vector

#include <iostream>
#include <vector>

void print_vector(std::vector<int>& nums) { 
    for (auto it = nums.begin(); it != nums.end(); ++it) { 
        std::cout << *it; // This Prints the current element
        if (it + 1 != nums.end()) { // It Checks if this is not the last element
            std::cout << ", "; 
        }
    }
    std::cout << std::endl; 
}
int main() {
    std::vector<int> my_vector = {4, 5, 6, -7, 8};
    print_vector(my_vector); // Call the function
    return 0;
}
