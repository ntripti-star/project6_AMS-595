// Question 4.1; Test for Prime Numbers

#include <iostream>
#include <cmath>

bool isprime(int n) {
    if (n <= 1) return false;  // Numbers <= 1 are not prime
    if (n == 2) return true;   // 2 is prime
    if (n % 2 == 0) return false; // Even numbers other than 2 are not prime

    for (int i = 3; i <= std::sqrt(n); i += 2) { // Check for the odd divisors up to sqrt(n)
        if (n % i == 0) {
            return false; // Found a divisor, not prime
        }
    }
    return true; // Prime number
}

void test_isprime() {
    std::cout << "isprime(2) = " << isprime(2) << '\n';   // Should print 1 (true)
    std::cout << "isprime(10) = " << isprime(10) << '\n'; // Should print 0 (false)
    std::cout << "isprime(17) = " << isprime(17) << '\n'; // Should print 1 (true)
}

int main() {
    test_isprime();
    return 0;
}
