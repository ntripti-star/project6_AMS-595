// Question 4.2 : Factorize

#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

// Here we write a function to find all factors of a number and then test for numbers 2, 72 and 196
std::vector<int> factorize(int n) {
    std::vector<int> answer;

    // Loop to find factors up to sqrt(n)
    for (int i = 1; i <= std::sqrt(n); ++i) {
        if (n % i == 0) {
            answer.push_back(i);           // we add the factor 
            if (i != n / i) {
                answer.push_back(n / i);   // Then Add the complementary factor
            }
        }
    }
    std::sort(answer.begin(), answer.end()); // Sorting of  the factors is done in ascending order
    return answer;
}

// Utility function to print a vector
void print_vector(const std::vector<int>& vec) {
    for (int val : vec) {
        std::cout << val << " ";
    }
    std::cout << std::endl;
}

// Test cases
void test_factorize() {
    std::cout << "Factors of 2: ";
    print_vector(factorize(2));

    std::cout << "Factors of 72: ";
    print_vector(factorize(72));

    std::cout << "Factors of 196: ";
    print_vector(factorize(196));
}

int main() {
    test_factorize();
    return 0;
}
