// Question 4.3 Prime Factorization


#include <iostream>
#include <vector>
#include <cmath>

// We complete the given Function to perform prime factorization of a number and then test for numbers 2, 72, 196

std::vector<int> prime_factorize(int n) {
    std::vector<int> answer;

    // Divide out all factors of 2
    while (n % 2 == 0) {
        answer.push_back(2);
        n /= 2;
    }

    // Divide by odd numbers from 3 to sqrt(n)
    for (int i = 3; i <= std::sqrt(n); i += 2) {
        while (n % i == 0) {
            answer.push_back(i);
            n /= i;
        }
    }

    // If remaining number is a prime number greater than 2
    if (n > 2) {
        answer.push_back(n);
    }

    return answer;
}

//  function to print a vector
void print_vector(const std::vector<int>& vec) {
    for (int val : vec) {
        std::cout << val << " ";
    }
    std::cout << std::endl;
}

// Test function to check the prime factorization
void test_prime_factorize() {
    std::cout << "Prime factors of 2: ";
    print_vector(prime_factorize(2));

    std::cout << "Prime factors of 72: ";
    print_vector(prime_factorize(72));

    std::cout << "Prime factors of 196: ";
    print_vector(prime_factorize(196));
}

// Main function
int main() {
    test_prime_factorize();
    return 0;
}
