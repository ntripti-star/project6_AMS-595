#include <iostream>
#include <vector>
using namespace std;

// Here we write a Function to generate a specific row of Pascal's Triangle iteratively
vector<int> generate_row(const vector<int>& previous_row) {
    vector<int> current_row;
    current_row.push_back(1); // The first element is always 1
    for (size_t i = 1; i < previous_row.size(); i++) {
        current_row.push_back(previous_row[i - 1] + previous_row[i]); // Sum of two elements above
    }
    current_row.push_back(1); // The last element is always 1
    return current_row;
}

// Function that prints the first n rows of Pascal's Triangle
void print_pascals_triangle_iterative(int n) {
    vector<int> row = {1}; 
    for (int i = 0; i < n; i++) {
        for (int value : row) {
            cout << value << " "; // Print each value in the row
        }
        cout << endl; // Move to the next line
        row = generate_row(row); // Generate the next row
    }
}

int main() {
    int n;
    cout << "Enter the number of rows for Pascal's Triangle: ";
    cin >> n;
    print_pascals_triangle_iterative(n); // Call the iterative function
    return 0;
}
