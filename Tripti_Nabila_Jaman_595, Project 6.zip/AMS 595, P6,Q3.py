#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import matplotlib.pyplot as plt

# First We Define the sigmoid activation function
def sigmoid(z):
    """Compute the sigmoid of z."""
    return 1 / (1 + np.exp(-z))

# We set the random seed for reproducibility
np.random.seed(595)

#Then we generate random data points for two features
X = np.random.rand(2, 100)  # Shape (2, 100): Two features, 100 samples

# Then we define true weights and bias
w_true = np.array([1.5, -2.5])  # True weights
b_true = 1.0  # True bias

# Calculate probabilities using the true weights and bias
probabilities = sigmoid(np.dot(w_true.T, X) + b_true)

# Generate binary labels based on the probabilities
Y = (probabilities > 0.5).astype(int)

# We have Added some noise to the data
X = X + 0.3 * np.random.rand(2, 100) - 0.1 * np.random.rand(2, 100)

# Then we Split the data into training and testing sets
X_train, X_test = X[:, :80], X[:, 80:]  # 80% for training, 20% for testing
Y_train, Y_test = Y[:80], Y[80:]  # Corresponding labels

# Initialize weights and bias
w = np.zeros(X.shape[0])  # Initialize weights to zero
b = 0.0  # Initialize bias to zero

# Fixing Hyperparameters
learning_rate = 0.5  # Adjusted learning rate for better convergence
num_epochs = 500  # Adjusted number of epochs

# Performing gradient descent
for epoch in range(num_epochs):
    # Forward pass: Compute predictions using the sigmoid function
    A_train = sigmoid(np.dot(w.T, X_train) + b)

    # Compute gradients for weights and bias
    dJdw = np.dot(X_train, (A_train - Y_train).T) / len(Y_train)
    dJdb = np.mean(A_train - Y_train)

    # Update weights and bias using gradient descent
    w -= learning_rate * dJdw
    b -= learning_rate * dJdb

# Evaluate the model on the training set
A_train = sigmoid(np.dot(w.T, X_train) + b)
predictions_train = (A_train > 0.5).astype(int)

# Evaluate the model on the testing set
A_test = sigmoid(np.dot(w.T, X_test) + b)
predictions_test = (A_test > 0.5).astype(int)

# Calculate accuracy
train_accuracy = np.mean(predictions_train == Y_train)
test_accuracy = np.mean(predictions_test == Y_test)

# Print accuracies
print(f"Training Set Accuracy: {train_accuracy:.2f}")
print(f"Test Set Accuracy: {test_accuracy:.2f}")

# Plot decision boundary for training data
plt.scatter(X[0, :80], X[1, :80], c=Y[:80], cmap=plt.cm.Paired)
plt.xlim(-0.2, 1.2)
plt.ylim(-0.2, 1.2)
ax = plt.gca()

# Define grid for decision boundary
xlim = ax.get_xlim()
ylim = ax.get_ylim()
xx, yy = np.meshgrid(np.linspace(xlim[0], xlim[1], 50), np.linspace(ylim[0], ylim[1], 50))
Z = np.dot(w.T, np.c_[xx.ravel(), yy.ravel()].T) + b
Z = sigmoid(Z)
Z = Z.reshape(xx.shape)

# Plot decision boundary
plt.contour(xx, yy, Z, colors='k', levels=[0.5], alpha=0.5, linestyles=['--'])
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Logistic Regression Decision Boundary (Training Data)')
plt.show()

# Plot decision boundary for testing data
plt.scatter(X[0, 80:], X[1, 80:], c=Y[80:], cmap=plt.cm.Paired)
plt.xlim(-0.2, 1.2)
plt.ylim(-0.2, 1.2)
ax = plt.gca()

# Define grid for decision boundary
xlim = ax.get_xlim()
ylim = ax.get_ylim()
xx, yy = np.meshgrid(np.linspace(xlim[0], xlim[1], 50), np.linspace(ylim[0], ylim[1], 50))
Z = np.dot(w.T, np.c_[xx.ravel(), yy.ravel()].T) + b
Z = sigmoid(Z)
Z = Z.reshape(xx.shape)

# Plot decision boundary
plt.contour(xx, yy, Z, colors='k', levels=[0.5], alpha=0.5, linestyles=['--'])
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Logistic Regression Decision Boundary (Testing Data)')
plt.show()


# In[ ]:




