#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Generate synthetic data
np.random.seed(87)  # Changed the seed according to the last two digits of my SBU ID number
X = 2 * np.random.rand(100, 2)  # Generate 100 random 2D data points
y = 4 + 4 * X[:, 0] + 0.5 * X[:, 1] + np.random.randn(100)  # Generate y values with noise

# Add a column of ones to X for the bias terms (intercept) in the normal equation
X_bias = np.c_[np.ones((100, 1)), X]

# Find theta using the normal equation
theta = np.linalg.inv(X_bias.T @ X_bias) @ (X_bias.T @ y)

# Print the intercept and coefficients of the regression plane
intercept = theta[0]
coefficients = theta[1:]
print(f"Intercept: {intercept}")
print(f"Coefficients: {coefficients}")

# Plot the generated data and the regression plane
figr = plt.figure(figsize=(12, 8))
axs = figr.add_subplot(111, projection='3d')

# Scatter plot of the original data
axs.scatter(X[:, 0], X[:, 1], y, color='blue', label='Original Data', alpha=0.6)

# Create a grid for the plane
x1_grid, x2_grid = np.meshgrid(np.linspace(0, 2, 50), np.linspace(0, 2, 50))
y_grid = intercept + coefficients[0] * x1_grid + coefficients[1] * x2_grid

# Plot the regression plane
axs.plot_surface(x1_grid, x2_grid, y_grid, color='yellow', alpha=0.5)

# Label the axes
axs.set_title("Linear Regression Plane")
axs.set_xlabel("X1")
axs.set_ylabel("X2")
axs.set_zlabel("y")
axs.legend()

plt.show()


# In[ ]:




