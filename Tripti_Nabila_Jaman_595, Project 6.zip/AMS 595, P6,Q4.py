#!/usr/bin/env python
# coding: utf-8

# In[4]:


import h5py
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# First we Load the datasets
train_dataset = h5py.File(r"F:\AMS_FALL_2024\AMS_595_FALL_2024\train_catvnoncat.h5", "r")
test_dataset = h5py.File(r"F:\AMS_FALL_2024\AMS_595_FALL_2024\test_catvnoncat.h5", "r")

# Then we Extract the data
train_x_original = np.array(train_dataset["train_set_x"][:])  # Train features
train_y = np.array(train_dataset["train_set_y"][:])  # Train labels
test_x_original = np.array(test_dataset["test_set_x"][:])  # Test features
test_y = np.array(test_dataset["test_set_y"][:])  # Test labels

# After that we Reshape labels to match dimensions
train_y = train_y.reshape((1, train_y.shape[0]))
test_y = test_y.reshape((1, test_y.shape[0]))

# Then we Flatten the images
train_x_flatt = train_x_original.reshape(train_x_original.shape[0], -1).T
test_x_flatt = test_x_original.reshape(test_x_original.shape[0], -1).T

# Then we Normalize the pixel values
train_x = train_x_flatt / 255.0
test_x = test_x_flatt / 255.0

# After that we Train logistic regression model
clf = LogisticRegression(max_iter=1000)
clf.fit(train_x.T, train_y.T.ravel())  # Train the model

# Make predictions
train_preds = clf.predict(train_x.T)
test_preds = clf.predict(test_x.T)

# Calculate the accuracies
train_accuracy = accuracy_score(train_y.T, train_preds)
test_accuracy = accuracy_score(test_y.T, test_preds)

print(f"Training Accuracy: {train_accuracy * 100:.2f}%")
print(f"Testing Accuracy: {test_accuracy * 100:.2f}%")

# We Identify misclassified indices
misclassified_indices = np.where(test_preds != test_y.T.ravel())[0]

# Display misclassified indices
print("Indices of misclassified images:", misclassified_indices)

# Display 4 misclassified images
plt.figure(figsize=(10, 10))
for i, idx in enumerate(misclassified_indices[:4]):
    plt.subplot(2, 2, i + 1)
    plt.imshow(test_x_orig[idx])  # Correctly index the original test dataset
    plt.title(f"True Label: {test_y.T[idx]}, Predicted: {test_preds[idx]}")
    plt.axis('off')
plt.show()

# New training set: First 160 images + last 5 images
new_train_x = np.concatenate([train_x[:, :160], train_x[:, -5:]], axis=1)
new_train_y = np.concatenate([train_y[:, :160], train_y[:, -5:]], axis=1)

# New test set: Remaining images from the original training set
new_test_x = train_x[:, 160:-5]
new_test_y = train_y[:, 160:-5]

# Train the model again with the new dataset
clf.fit(new_train_x.T, new_train_y.T.ravel())

# Make predictions
new_train_pred = clf.predict(new_train_x.T)
new_test_pred = clf.predict(new_test_x.T)

# Calculate accuracies
new_train_accuracy = accuracy_score(new_train_y.T, new_train_pred)
new_test_accuracy = accuracy_score(new_test_y.T, new_test_pred)

print(f"New Training Accuracy: {new_train_accuracy * 100:.2f}%")
print(f"New Testing Accuracy: {new_test_accuracy * 100:.2f}%")

# Identify misclassified indices in the new test set
new_misclassified_indices = np.where(new_test_pred != new_test_y.T.ravel())[0]

# Display misclassified indices
print("Indices of misclassified images (new test set):", new_misclassified_indices)

# Display 4 misclassified images
plt.figure(figsize=(10, 10))
for i, idx in enumerate(new_misclassified_indices[:4]):
    plt.subplot(2, 2, i + 1)
    plt.imshow(train_x_orig[idx + 160])  # Properly map back to the original dataset
    plt.title(f"True Label: {new_test_y.T[idx]}, Predicted: {new_test_preds[idx]}")
    plt.axis('off')
plt.show()


# In[ ]:




