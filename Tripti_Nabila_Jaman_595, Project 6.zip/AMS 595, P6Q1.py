#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt

# Define the function f(x)= sqrt(x**2+5)
def f(x):
    return np.sqrt(x**2 + 5)

# Define the derivative of f(x) for finding gradient descent
def grad_f(x):
    return x / np.sqrt(x**2 + 5)

# Function to run Gradient Descent Method
def gradient_descent(x_0, step_size, num_iterations):
    x_k = [x_0]
    for _ in range(num_iterations):
        x_new = x_k[-1] - step_size * grad_f(x_k[-1])
        x_k.append(x_new)
    return x_k

# Initial values
x_0 = 2.0  # Derived from my ID
num_iterations = 50  # Number of iterations
step_sizes = [5, 3, 1, 0.5]  # Different step sizes to test

# Plot the function f(x) over the interval [-5, 5]
x_vals = np.linspace(-5, 5, 500)
y_vals = f(x_vals)

plt.figure(figsize=(8, 6))
plt.plot(x_vals, y_vals, label=r"$f(x) = \sqrt{x^2 + 5}$", color="blue")
plt.scatter(0,f(0), color="red", label="Minimum", zorder=5)
plt.title("Plot of f(x) = sqrt(x^2 + 5) and finding Minimum ")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.grid(True)
plt.legend()
plt.show()

# Run gradient descent for each step size and record results
results = {}

for alpha in step_sizes:
    x_k = gradient_descent(x_0, alpha, num_iterations)
    f_k = [f(x) for x in x_k]
    results[alpha] = (x_k, f_k)

# Plot f(x_k) vs. iteration number for each step size
plt.figure(figsize=(10, 8))

for alpha, (_, f_k) in results.items():
    plt.plot(range(num_iterations + 1), f_k, label=f"Step size α={alpha}")

plt.title("f(x_k) vs. Iteration Number")
plt.xlabel("Iteration Number")
plt.ylabel("f(x_k)")
plt.grid(True)
plt.legend()
plt.show()

# Plot f(x_{k-1}) - f(x_k) vs. iteration number for each step size
plt.figure(figsize=(10, 8))

for alpha, (_, f_k) in results.items():
    f_diff = [f_k[i - 1] - f_k[i] for i in range(1, len(f_k))]
    plt.plot(range(1, num_iterations + 1), f_diff, label=f"Step size α={alpha}")

plt.title("f(x_{k-1}) - f(x_k) vs. Iteration Number")
plt.xlabel("Iteration Number")
plt.ylabel("f(x_{k-1}) - f(x_k)")
plt.grid(True)
plt.legend()
plt.show()


# In[ ]:




